<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ApiResource()
 * @ORM\Entity(repositoryClass="App\Repository\PlaneRepository")
 */
class Plane
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $reference;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $model;

    /**
     * @ORM\Column(type="integer")
     */
    private $firstClassPlaces;

    /**
     * @ORM\Column(type="integer")
     */
    private $secondClassPlaces;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Compagny", inversedBy="planes")
     */
    private $compagny;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $status;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getReference(): ?string
    {
        return $this->reference;
    }

    public function setReference(string $reference): self
    {
        $this->reference = $reference;

        return $this;
    }

    public function getModel(): ?string
    {
        return $this->model;
    }

    public function setModel(string $model): self
    {
        $this->model = $model;

        return $this;
    }

    public function getFirstClassPlaces(): ?int
    {
        return $this->firstClassPlaces;
    }

    public function setFirstClassPlaces(int $firstClassPlaces): self
    {
        $this->firstClassPlaces = $firstClassPlaces;

        return $this;
    }

    public function getSecondClassPlaces(): ?int
    {
        return $this->secondClassPlaces;
    }

    public function setSecondClassPlaces(int $secondClassPlaces): self
    {
        $this->secondClassPlaces = $secondClassPlaces;

        return $this;
    }

    public function getCompagny(): ?Compagny
    {
        return $this->compagny;
    }

    public function setCompagny(?Compagny $compagny): self
    {
        $this->compagny = $compagny;

        return $this;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function setStatus(string $status): self
    {
        $this->status = $status;

        return $this;
    }
}
